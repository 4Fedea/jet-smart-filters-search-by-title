<?php
namespace JSF_SBTITLE;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main file
 */
class Plugin {

	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	private $search_query = null;

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;

	}

	public function maybe_hook_title_clause( $query ) {
		$data = isset( $_REQUEST['query'] ) ? $_REQUEST['query'] : $_REQUEST;

		foreach ( $data as $key => $value ) {
			if ( false !== strpos( $key, '|search' ) ) {
				$this->search_query = esc_sql( $value );
				add_filter( 'posts_where', array( $this, 'add_title_clause' ), 10, 2 );
			}
		}

		return $query;
	}

	public function add_title_clause( $where, $query ) {

		if ( ! $this->search_query || ! $query->get( 'jet_smart_filters' ) ) {
			return $where;
		}

		global $wpdb;

		$where .= " OR ( ";

		if ( $exact_match = apply_filters( 'jet-smart-filters-search-by-title/exact-match', true ) ) {
			$where .= "{$wpdb->posts}.post_title = {$this->search_query}";
		} else {
			
			$search_terms = explode(' ', $this->search_query);
			
			$like_clauses = [];
			foreach ($search_terms as $term) {
				
				$term = trim($term);
				if (!empty($term)) {
					$like_clauses[] = "{$wpdb->posts}.post_title LIKE '%{$term}%'";
				}
			}

			
			$like_string = implode(' AND ', $like_clauses);
			$where .= $like_string;
		}

		if ( ! empty( $query->query['post_type'] ) ) {
			if ( is_array( $query->query['post_type'] ) ) {

				$post_types = array_map( function( $item ) {
					$item = esc_sql( $item );
					return "'{$item}'";
				}, $query->query['post_type'] );

				$post_types = implode( ', ', $post_types );
				$where .= " AND {$wpdb->posts}.post_type IN ( {$post_types} )";

			} else {

				$post_type = esc_sql( $query->query['post_type'] );
				$where .= " AND {$wpdb->posts}.post_type IN ( '{$post_type}' )";

			}
		}

		$where .= " AND {$wpdb->posts}.post_status = 'publish' )";

		$this->search_query = null;
		remove_filter( 'posts_where', array( $this, 'add_title_clause' ), 10, 2 );

		return $where;

	}

	/**
	 * Plugin constructor.
	 */
	private function __construct() {
		add_action( 'jet-smart-filters/query/final-query', array( $this, 'maybe_hook_title_clause' ) );
	}

}

Plugin::instance();
