<?php
/**
 * Plugin Name: JetSmartFilters - Search posts by Title
 * Plugin URI:  https://crocoblock.com/
 * Description: Allow to search by post Title in the JetSmartFilter's search filter by Fd
 * Version:     1.0.0
 * Author:      Crocoblock
 * Author URI:  https://crocoblock.com/
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

add_action( 'plugins_loaded', function() {

	define( 'JSF_SBTITLE_VERSION', '1.0.0' );

	define( 'JSF_SBTITLE__FILE__', __FILE__ );
	define( 'JSF_SBTITLE_PATH', plugin_dir_path( JSF_SBTITLE__FILE__ ) );

	require JSF_SBTITLE_PATH . 'includes/plugin.php';

} );
